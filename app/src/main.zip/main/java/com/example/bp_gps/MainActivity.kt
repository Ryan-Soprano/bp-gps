package com.example.bp_gps

import android.Manifest
import android.annotation.SuppressLint
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.net.toUri
import com.example.bp_gps.service.NavigationService
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREFS = "bp_gps_prefs"
        private const val KEY_OFFICER_ID = "officer_id"
        private const val KEY_FILTER_ENABLED = "filter_enabled"

        // history storage (written by service)
        private const val HISTORY_PREFS = "bp_gps_dispatch_history"
        private const val HISTORY_KEY = "dispatch_history"
    }

    // Views
    private lateinit var serviceStatus: TextView
    private lateinit var connectionStatus: TextView
    private lateinit var statusDetail: TextView
    private lateinit var tvOfficerCaption: TextView
    private lateinit var btnEditRcn: Button
    private lateinit var btnToggleFilter: Button
    private lateinit var recentList: ListView
    private lateinit var emptyView: TextView

    // Data
    private val displayItems = mutableListOf<HistoryItem>()
    private lateinit var adapter: ArrayAdapter<String>

    data class HistoryItem(val address: String, val officerId: String, val timestamp: Long)

    // Receiver for status updates from the Service
    private lateinit var statusReceiver: BroadcastReceiver

    // Permission request
    private val requestNotifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                promptForOfficerId()
            } else {
                Toast.makeText(this, R.string.toast_notifications_required, Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        serviceStatus      = findViewById(R.id.serviceStatusText)
        connectionStatus   = findViewById(R.id.connectionStatusText)
        statusDetail       = findViewById(R.id.statusDetailText)
        tvOfficerCaption   = findViewById(R.id.tvOfficerCaption)
        btnEditRcn         = findViewById(R.id.btnEditRcn)
        btnToggleFilter    = findViewById(R.id.btnToggleFilter)
        recentList         = findViewById(R.id.recentList)
        emptyView          = findViewById(R.id.emptyText)

        // list adapter
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        recentList.adapter = adapter
        recentList.emptyView = emptyView
        recentList.setOnItemClickListener { _, _, pos, _ ->
            if (pos in displayItems.indices) {
                openInMaps(displayItems[pos].address)
            }
        }

        setupButtons()
        setupStatusReceiver()
        checkPermissionsAndStart()
    }

    private fun setupButtons() {
        btnEditRcn.setOnClickListener { promptForOfficerId() }
        btnToggleFilter.setOnClickListener {
            val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
            val now = !prefs.getBoolean(KEY_FILTER_ENABLED, true)
            prefs.edit { putBoolean(KEY_FILTER_ENABLED, now) }
            updateFilterButton()
            loadAndDisplayHistory() // refresh immediately
        }
        updateOfficerCaption()
        updateFilterButton()
    }

    private fun setupStatusReceiver() {
        statusReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == NavigationService.STATUS_UPDATE_ACTION) {
                    val code   = intent.getStringExtra(NavigationService.EXTRA_STATUS_CODE).orEmpty()
                    val detail = intent.getStringExtra(NavigationService.EXTRA_DETAIL).orEmpty()
                    updateStatusUIByCode(code, detail)
                }
            }
        }
    }

    // ----- UI updates -----

    private fun updateOfficerCaption() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val id = prefs.getString(KEY_OFFICER_ID, "").orEmpty()
        tvOfficerCaption.text = if (id.isNotEmpty()) {
            getString(R.string.caption_officer_id, id)
        } else {
            getString(R.string.caption_officer_none)
        }
    }

    private fun updateFilterButton() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val enabled = prefs.getBoolean(KEY_FILTER_ENABLED, true)
        btnToggleFilter.text = if (enabled) {
            getString(R.string.button_show_all)
        } else {
            getString(R.string.button_filter_to_rcn)
        }
    }

    private fun updateStatusUIByCode(code: String, detail: String) {
        val title = when (code) {
            NavigationService.CODE_CONNECTED         -> getString(R.string.ui_title_connected)
            NavigationService.CODE_CONNECTING        -> getString(R.string.ui_title_connecting)
            NavigationService.CODE_STARTING          -> getString(R.string.ui_title_starting)
            NavigationService.CODE_DISCONNECTED      -> getString(R.string.ui_title_reconnecting)
            NavigationService.CODE_CONNECTION_FAILED -> getString(R.string.ui_title_failed)
            NavigationService.CODE_DISPATCH          -> getString(R.string.ui_title_active)
            NavigationService.CODE_SETUP_FAILED      -> getString(R.string.ui_title_setup_error)
            NavigationService.CODE_STOPPED           -> getString(R.string.ui_title_stopped)
            else                                     -> getString(R.string.app_name)
        }
        val chip = when (code) {
            NavigationService.CODE_CONNECTED         -> getString(R.string.ui_chip_connected)
            NavigationService.CODE_CONNECTING        -> getString(R.string.ui_chip_connecting)
            NavigationService.CODE_STARTING          -> getString(R.string.ui_chip_starting)
            NavigationService.CODE_DISCONNECTED      -> getString(R.string.ui_chip_disconnected)
            NavigationService.CODE_CONNECTION_FAILED -> getString(R.string.ui_chip_failed)
            NavigationService.CODE_DISPATCH          -> getString(R.string.ui_chip_active)
            NavigationService.CODE_SETUP_FAILED      -> getString(R.string.ui_chip_setup_error)
            NavigationService.CODE_STOPPED           -> getString(R.string.ui_chip_stopped)
            else                                     -> getString(R.string.ui_chip_unknown, code)
        }
        serviceStatus.text = chip
        connectionStatus.text = title
        statusDetail.text = if (detail.isNotEmpty()) detail else getString(R.string.ui_detail_default, title)
    }

    // ----- lifecycle -----

    override fun onResume() {
        super.onResume()
        ContextCompat.registerReceiver(
            this,
            statusReceiver,
            IntentFilter(NavigationService.STATUS_UPDATE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        // keep UI in sync when returning to foreground
        updateOfficerCaption()
        updateFilterButton()
        loadAndDisplayHistory()
    }

    override fun onPause() {
        super.onPause()
        runCatching { unregisterReceiver(statusReceiver) }
    }

    // ----- permissions / start -----

    private fun checkPermissionsAndStart() {
        statusDetail.text = getString(R.string.detail_checking_permissions)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                requestNotifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        promptForOfficerId()
    }

    @SuppressLint("SetTextI18n")
    private fun promptForOfficerId() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val cached = prefs.getString(KEY_OFFICER_ID, "").orEmpty()

        val input = EditText(this).apply {
            hint = getString(R.string.hint_officer_id)
            setText(cached)
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_login_title)
            .setMessage(R.string.dialog_login_msg)
            .setView(input)
            .setCancelable(false)
            .setPositiveButton(R.string.button_ok) { _, _ ->
                val id = input.text.toString().trim()
                if (id.isNotEmpty()) {
                    prefs.edit { putString(KEY_OFFICER_ID, id) }
                    updateOfficerCaption()
                    loadAndDisplayHistory()          // refresh list for new RCN
                    startServiceWithOfficer(id)      // update Service with new RCN
                } else {
                    Toast.makeText(this, R.string.toast_officer_required, Toast.LENGTH_SHORT).show()
                    promptForOfficerId()
                }
            }
            .show()
    }

    private fun startServiceWithOfficer(officerId: String) {
        val i = Intent(this, NavigationService::class.java).putExtra("officer_id", officerId)
        startForegroundService(i)
        Toast.makeText(this, getString(R.string.toast_service_started, officerId), Toast.LENGTH_SHORT).show()
    }

    // ----- history list -----

    private fun loadAndDisplayHistory() {
        val prefs = getSharedPreferences(HISTORY_PREFS, MODE_PRIVATE)
        val json = prefs.getString(HISTORY_KEY, null)

        displayItems.clear()
        val rows = mutableListOf<String>()

        val currentRcn = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_OFFICER_ID, "").orEmpty()
        val filterEnabled = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_FILTER_ENABLED, true)

        if (json != null) {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o: JSONObject = arr.getJSONObject(i)
                val item = HistoryItem(
                    address = o.getString("address"),
                    officerId = o.optString("officerId", ""),
                    timestamp = o.getLong("timestamp")
                )
                if (!filterEnabled || item.officerId.equals(currentRcn, ignoreCase = true)) {
                    displayItems.add(item)
                }
            }
        }

        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        rows.addAll(displayItems.map {
            "📍 ${it.address}" + if (it.officerId.isNotBlank()) " (${it.officerId})" else "" +
                    "\n   ${fmt.format(Date(it.timestamp))}"
        })

        if (rows.isEmpty()) {
            emptyView.text = getString(R.string.empty_no_dispatches)
        }

        adapter.clear()
        adapter.addAll(rows)
        adapter.notifyDataSetChanged()
    }

    private fun openInMaps(address: String) {
        runCatching {
            val uri = "geo:0,0?q=${Uri.encode(address)}".toUri()
            startActivity(Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.apps.maps")
            })
        }.onFailure {
            Toast.makeText(this, R.string.notif_maps_launch_failed, Toast.LENGTH_SHORT).show()
        }
    }
}
