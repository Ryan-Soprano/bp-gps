package com.example.bp_gps

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.SimpleAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.net.toUri
import com.example.bp_gps.service.NavigationService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val officerIdKey = "officer_id"

    private lateinit var serviceStatus: TextView
    private lateinit var connectionStatus: TextView
    private lateinit var statusDetail: TextView
    private lateinit var currentOfficerText: TextView
    private lateinit var editOfficerButton: Button
    private lateinit var filterToggleButton: Button
    private lateinit var historyListView: ListView

    private lateinit var statusReceiver: BroadcastReceiver
    private lateinit var historyReceiver: BroadcastReceiver
    private lateinit var officerIdReceiver: BroadcastReceiver

    private var navigationService: NavigationService? = null
    private var serviceBound = false
    private var currentOfficerId: String = ""
    private var showAllAddresses = false // Filter state

    private lateinit var historyAdapter: SimpleAdapter

    private fun initializeHistoryAdapter() {
        val historyData = mutableListOf<Map<String, String>>()
        historyAdapter = SimpleAdapter(
            this,
            historyData,
            android.R.layout.simple_list_item_2,
            arrayOf("address", "details"),
            intArrayOf(android.R.id.text1, android.R.id.text2)
        )
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            // We don't actually need to bind to the service for this app,
            // but keeping this structure in case we need it later
            serviceBound = true
            refreshHistoryList()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            navigationService = null
        }
    }

    private val requestNotifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                promptForOfficerId()
            } else {
                Toast.makeText(this, R.string.toast_notifications_required, Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeViews()
        setupReceivers()
        setupClickListeners()
        checkPermissionsAndStart()
    }

    private fun initializeViews() {
        serviceStatus = findViewById(R.id.serviceStatusText)
        connectionStatus = findViewById(R.id.connectionStatusText)
        statusDetail = findViewById(R.id.statusDetailText)
        currentOfficerText = findViewById(R.id.currentOfficerText)
        editOfficerButton = findViewById(R.id.editOfficerButton)
        filterToggleButton = findViewById(R.id.filterToggleButton)
        historyListView = findViewById(R.id.historyListView)

        initializeHistoryAdapter()
        historyListView.adapter = historyAdapter

        // Load current officer ID
        val prefs = getSharedPreferences("bp_gps_prefs", MODE_PRIVATE)
        currentOfficerId = prefs.getString(officerIdKey, "") ?: ""
        updateOfficerDisplay()
        updateFilterButtonText()
    }

    private fun setupClickListeners() {
        editOfficerButton.setOnClickListener {
            showEditOfficerDialog()
        }

        filterToggleButton.setOnClickListener {
            toggleFilter()
        }

        historyListView.setOnItemClickListener { _, _, position, _ ->
            val item = historyAdapter.getItem(position) as? Map<String, String>
            val address = item?.get("address")
            if (!address.isNullOrEmpty()) {
                navigateToAddress(address)
            }
        }
    }

    private fun setupReceivers() {
        // Status updates from service
        statusReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == NavigationService.STATUS_UPDATE_ACTION) {
                    val status = intent.getStringExtra(NavigationService.EXTRA_STATUS).orEmpty()
                    val detail = intent.getStringExtra(NavigationService.EXTRA_DETAIL).orEmpty()
                    updateStatusUI(status, detail)
                }
            }
        }

        // History updates from service
        historyReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == NavigationService.HISTORY_UPDATE_ACTION) {
                    refreshHistoryList()
                }
            }
        }

        // Officer ID changes from service
        officerIdReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == NavigationService.OFFICER_ID_CHANGED_ACTION) {
                    val officerId = intent.getStringExtra(NavigationService.EXTRA_OFFICER_ID) ?: ""
                    currentOfficerId = officerId
                    updateOfficerDisplay()
                    refreshHistoryList()
                }
            }
        }
    }

    private fun updateOfficerDisplay() {
        currentOfficerText.text = if (currentOfficerId.isNotEmpty()) {
            getString(R.string.current_officer_format, currentOfficerId)
        } else {
            getString(R.string.no_officer_selected)
        }
    }

    private fun updateFilterButtonText() {
        filterToggleButton.text = if (showAllAddresses) {
            getString(R.string.filter_button_show_mine)
        } else {
            getString(R.string.filter_button_show_all)
        }
    }

    private fun toggleFilter() {
        showAllAddresses = !showAllAddresses
        updateFilterButtonText()
        refreshHistoryList()

        val message = if (showAllAddresses) {
            getString(R.string.toast_showing_all_addresses)
        } else {
            getString(R.string.toast_showing_officer_addresses, currentOfficerId)
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun refreshHistoryList() {
        val history = loadDispatchHistory()
        val historyData = mutableListOf<Map<String, String>>()

        val dateFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())

        for (item in history) {
            val details = buildString {
                append(dateFormat.format(Date(item.timestamp)))
                if (item.officerId.isNotEmpty()) {
                    append(" • Officer: ${item.officerId}")
                }
            }

            historyData.add(
                mapOf(
                    "address" to item.address,
                    "details" to details
                )
            )
        }

        // Recreate the adapter with new data
        historyAdapter = SimpleAdapter(
            this,
            historyData,
            android.R.layout.simple_list_item_2,
            arrayOf("address", "details"),
            intArrayOf(android.R.id.text1, android.R.id.text2)
        )
        historyListView.adapter = historyAdapter

        // Show/hide the list based on whether we have data
        historyListView.visibility = if (historyData.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun loadDispatchHistory(): List<NavigationService.DispatchHistoryItem> {
        return try {
            val prefs = getSharedPreferences("bp_gps_dispatch_history", Context.MODE_PRIVATE)
            val json = prefs.getString("dispatch_history", null) ?: return emptyList()
            val arr = org.json.JSONArray(json)
            val allHistory = MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                NavigationService.DispatchHistoryItem(
                    address = o.getString("address"),
                    timestamp = o.getLong("timestamp"),
                    officerId = o.optString("officerId", ""),
                    dispatchId = o.optString("dispatchId", "")
                )
            }

            // Apply filtering based on current state
            if (showAllAddresses || currentOfficerId.isEmpty()) {
                allHistory
            } else {
                allHistory.filter { it.officerId == currentOfficerId }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun navigateToAddress(address: String) {
        try {
            val encoded = Uri.encode(address)
            val uri = "geo:0,0?q=$encoded".toUri()
            val mapIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.apps.maps")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(mapIntent)
            Toast.makeText(this, getString(R.string.toast_navigating_to, address), Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, getString(R.string.toast_navigation_failed), Toast.LENGTH_SHORT).show()
        }
    }

    private fun showEditOfficerDialog() {
        val input = EditText(this).apply {
            setText(currentOfficerId)
            hint = getString(R.string.hint_officer_id)
            selectAll() // Select current text for easy editing
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_edit_officer_title)
            .setMessage(R.string.dialog_edit_officer_msg)
            .setView(input)
            .setPositiveButton(R.string.button_save) { _, _ ->
                val newId = input.text.toString().trim()
                if (newId.isNotEmpty()) {
                    updateOfficerId(newId)
                } else {
                    Toast.makeText(this, R.string.toast_officer_required, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.button_cancel, null)
            .show()
    }

    private fun updateOfficerId(newOfficerId: String) {
        val prefs = getSharedPreferences("bp_gps_prefs", MODE_PRIVATE)
        prefs.edit { putString(officerIdKey, newOfficerId) }

        currentOfficerId = newOfficerId
        updateOfficerDisplay()

        // Restart service with new officer ID
        restartServiceWithNewOfficerId(newOfficerId)

        // Refresh history to apply new filtering
        refreshHistoryList()

        Toast.makeText(this, getString(R.string.toast_officer_updated, newOfficerId), Toast.LENGTH_SHORT).show()
    }

    private fun restartServiceWithNewOfficerId(officerId: String) {
        val intent = Intent(this, NavigationService::class.java)
        intent.putExtra("officer_id", officerId)
        startForegroundService(intent)
    }

    private fun updateStatusUI(status: String, detail: String) {
        val title = when (status) {
            getString(R.string.status_connected) -> getString(R.string.ui_title_connected)
            getString(R.string.status_connecting) -> getString(R.string.ui_title_connecting)
            getString(R.string.status_starting) -> getString(R.string.ui_title_starting)
            getString(R.string.status_disconnected) -> getString(R.string.ui_title_reconnecting)
            getString(R.string.status_connection_failed) -> getString(R.string.ui_title_failed)
            getString(R.string.status_dispatch_received) -> getString(R.string.ui_title_active)
            getString(R.string.status_setup_failed) -> getString(R.string.ui_title_setup_error)
            getString(R.string.status_stopped) -> getString(R.string.ui_title_stopped)
            else -> getString(R.string.app_name)
        }
        val chip = when (status) {
            getString(R.string.status_connected) -> getString(R.string.ui_chip_connected)
            getString(R.string.status_connecting) -> getString(R.string.ui_chip_connecting)
            getString(R.string.status_starting) -> getString(R.string.ui_chip_starting)
            getString(R.string.status_disconnected) -> getString(R.string.ui_chip_disconnected)
            getString(R.string.status_connection_failed) -> getString(R.string.ui_chip_failed)
            getString(R.string.status_dispatch_received) -> getString(R.string.ui_chip_active)
            getString(R.string.status_setup_failed) -> getString(R.string.ui_chip_setup_error)
            getString(R.string.status_stopped) -> getString(R.string.ui_chip_stopped)
            else -> getString(R.string.ui_chip_unknown, status)
        }

        serviceStatus.text = chip
        connectionStatus.text = title
        statusDetail.text = if (detail.isNotEmpty()) detail
        else getString(R.string.ui_detail_default, status)
    }

    override fun onResume() {
        super.onResume()

        // Register all receivers
        ContextCompat.registerReceiver(
            this,
            statusReceiver,
            IntentFilter(NavigationService.STATUS_UPDATE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        ContextCompat.registerReceiver(
            this,
            historyReceiver,
            IntentFilter(NavigationService.HISTORY_UPDATE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        ContextCompat.registerReceiver(
            this,
            officerIdReceiver,
            IntentFilter(NavigationService.OFFICER_ID_CHANGED_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        // Pull the last known status in case we missed a broadcast
        syncLastKnownStatus()

        // Refresh history list
        refreshHistoryList()
    }

    override fun onPause() {
        super.onPause()
        runCatching {
            unregisterReceiver(statusReceiver)
            unregisterReceiver(historyReceiver)
            unregisterReceiver(officerIdReceiver)
        }
    }

    private fun syncLastKnownStatus() {
        val prefs = getSharedPreferences("bp_gps_last_status", Context.MODE_PRIVATE)
        val lastStatus = prefs.getString("status", null)
        val lastDetail = prefs.getString("detail", "") ?: ""
        if (!lastStatus.isNullOrEmpty()) {
            updateStatusUI(lastStatus, lastDetail)
        }
    }

    private fun checkPermissionsAndStart() {
        statusDetail.text = getString(R.string.detail_checking_permissions)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestNotifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        promptForOfficerId()
    }

    @SuppressLint("SetTextI18n")
    private fun promptForOfficerId() {
        val prefs = getSharedPreferences("bp_gps_prefs", MODE_PRIVATE)
        val cached = prefs.getString(officerIdKey, "")

        if (cached.isNullOrEmpty()) {
            statusDetail.text = getString(R.string.ui_detail_login_required)
            val input = EditText(this).apply { hint = getString(R.string.hint_officer_id) }
            AlertDialog.Builder(this)
                .setTitle(R.string.dialog_login_title)
                .setMessage(R.string.dialog_login_msg)
                .setView(input)
                .setCancelable(false)
                .setPositiveButton(R.string.button_ok) { _, _ ->
                    val id = input.text.toString().trim()
                    if (id.isNotEmpty()) {
                        prefs.edit { putString(officerIdKey, id) }
                        currentOfficerId = id
                        updateOfficerDisplay()
                        startServiceWithOfficer(id)
                    } else {
                        Toast.makeText(this, R.string.toast_officer_required, Toast.LENGTH_SHORT).show()
                        promptForOfficerId()
                    }
                }
                .show()
        } else {
            currentOfficerId = cached
            updateOfficerDisplay()
            statusDetail.text = getString(R.string.ui_detail_starting_for, cached)
            startServiceWithOfficer(cached)
        }
    }

    private fun startServiceWithOfficer(officerId: String) {
        val i = Intent(this, NavigationService::class.java).putExtra("officer_id", officerId)
        startForegroundService(i)
        Toast.makeText(this, getString(R.string.toast_service_started, officerId), Toast.LENGTH_SHORT).show()
    }
}